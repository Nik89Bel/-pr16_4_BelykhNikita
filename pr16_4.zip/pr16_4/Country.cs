﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pr16_4
{
    class Country
    {
        public string name { get; set; }
        public long chisl { get; set; }
    }
}
