﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.IO;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pr16_4
{
    public partial class Form1 : Form
    {
        List<Country> cntrs = new List<Country>();
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                textBox1.Clear();
                string[] lines = File.ReadAllLines("f1.txt");
                foreach (string line in lines)
                {
                    string[] parts = line.Split(' ');
                    if (parts.Length == 2)
                    {
                        string name = parts[0];
                        long chisl = long.Parse(parts[1]);
                        cntrs.Add(new Country { name = name, chisl = chisl });
                    }
                }
                textBox1.Text = File.ReadAllText("f1.txt");
            }
            catch { MessageBox.Show("Файл не найден", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error); }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                textBox2.Clear();
                long n = (long)numericUpDown1.Value;
                if (n != 0)
                {
                    var newcntrs = cntrs
                        .Where(c => c.chisl > n)
                        .OrderBy(c => c.name.Length)
                        .ThenBy(c => c.name);
                    foreach (var newcountry in newcntrs)
                    {
                        textBox2.Text += $"{newcountry.name} {newcountry.chisl}{Environment.NewLine}";
                    }
                }
                else
                    MessageBox.Show("Введите n", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch { MessageBox.Show("Файл не найден", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error); }
        }
    }
}
